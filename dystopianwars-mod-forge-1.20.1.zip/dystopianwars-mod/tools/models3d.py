"""3D miniature models built from cuboids (Minecraft block-model elements).
Every model fits a 16x16 footprint, bow points to NORTH (small z). Colour slots refer to the faction palette."""

M, D, L, S, K, G, W, A = range(8)  # main, dark, light(deck), steel, black, gold, white, accent


def b(x1, y1, z1, x2, y2, z2, slot):
    c = lambda v: round(min(16.0, max(0.0, v)), 3)
    return (c(x1), round(y1, 3), c(z1), c(x2), round(y2, 3), c(z2), slot)


def turret(cx, cz, y, size=2.4, barrels=1, length=3.0):
    out = [b(cx - size / 2, y, cz - size / 2, cx + size / 2, y + 1.2, cz + size / 2, S)]
    if barrels == 1:
        out.append(b(cx - 0.3, y + 0.5, cz - size / 2 - length, cx + 0.3, y + 1.0, cz - size / 2, K))
    else:
        for dx in (-0.5, 0.5):
            out.append(b(cx + dx - 0.25, y + 0.5, cz - size / 2 - length, cx + dx + 0.25, y + 1.0, cz - size / 2, K))
    return out


def stand(height, cx=8.0, cz=8.0):
    return [b(cx - 3, 0, cz - 3, cx + 3, 1, cz + 3, D), b(cx - 0.5, 1, cz - 0.5, cx + 0.5, height, cz + 0.5, S)]


def hull(w, length, h):
    x1, x2 = 8 - w / 2, 8 + w / 2
    z0 = (16 - length) / 2
    return [
        b(x1 + 0.7, 0, z0 + 1.5, x2 - 0.7, 1, z0 + length - 0.5, D),
        b(x1, 1, z0 + 2.5, x2, h, z0 + length, M),
        b(x1 + 1, 1, z0, x2 - 1, h, z0 + 2.5, M),
        b(x1 + 0.4, h, z0 + 1, x2 - 0.4, h + 0.5, z0 + length - 0.5, L),
    ], z0


def ship(w, length, h, turrets_z, funnels, bridge_h, barrels=1, heavy=False):
    parts, z0 = hull(w, length, h)
    y = h + 0.5
    for tz in turrets_z:
        parts += turret(8, z0 + tz, y, size=min(w - 1.2, 3.0), barrels=barrels)
    bz = z0 + length * 0.58
    parts.append(b(8 - w / 4 - 0.5, y, bz - 1.5, 8 + w / 4 + 0.5, y + bridge_h, bz + 1.5, S))
    parts.append(b(8 - w / 4, y + bridge_h - 1.2, bz - 1.7, 8 + w / 4, y + bridge_h - 0.5, bz - 1.5, K))  # windows
    parts.append(b(8 - 0.2, y + bridge_h, bz - 0.2, 8 + 0.2, y + bridge_h + 2.5, bz + 0.2, K))  # mast
    for i in range(funnels):
        fz = bz + 2.8 + i * 2.2
        if fz + 1 < z0 + length - 0.5:
            parts.append(b(7.2, y, fz - 0.6, 8.8, y + bridge_h - 0.5 + 0.8, fz + 0.6, K))
            parts.append(b(7.2, y + bridge_h + 0.3, fz - 0.6, 8.8, y + bridge_h + 0.7, fz + 0.6, M))
    return parts


def build(cls, heavy=False, signature=False):
    p = []
    if cls == "frigate":
        p = ship(4, 14, 3, [3.2], 1, 2.5)
    elif cls == "destroyer":
        p = ship(4, 15, 3, [3.0, 11.5], 2, 2.8, barrels=1)
        p.append(b(7.4, 3.5, 7.6, 8.6, 4.1, 9.6, K))  # torpedo tubes
    elif cls == "cruiser":
        w = 7 if heavy else 6
        p = ship(w, 15, 3, [3.0, 4.8, 12.5] if heavy else [3.2, 12.0], 2, 3.5, barrels=2 if heavy else 1)
    elif cls == "monitor":
        parts, z0 = hull(9, 12, 2.5)
        p = parts + turret(8, z0 + 4.2, 3.0, size=4.5, barrels=2, length=3.5)
        p += [b(6.5, 3.0, z0 + 8.2, 9.5, 5.5, z0 + 10.2, S), b(7.2, 5.5, z0 + 8.8, 8.8, 7.5, z0 + 9.6, K)]
    elif cls == "battleship":
        p = ship(8, 15, 3.5, [3.0, 5.2, 12.8], 2, 4.5, barrels=2)
    elif cls == "carrier":
        parts, z0 = hull(8, 15, 3)
        p = parts + [b(3.5, 3.0, z0 + 0.5, 12.5, 3.6, z0 + 14.5, L)]
        p += [b(10, 3.6, 7, 12.5, 7.5, 10, S), b(10.5, 7.5, 7.5, 12, 8.5, 9.5, K)]
        p += [b(5.5, 3.6, 4, 7, 4.2, 5, W), b(7.8, 3.6, 7, 9.2, 4.2, 8, W), b(5, 3.6, 10, 6.5, 4.2, 11, W)]
        p += [b(7.9, 3.6, z0 + 0.5, 8.1, 3.65, z0 + 14.5, W)]
    elif cls == "submarine":
        p = [b(7, 0, 3, 9, 1, 14, D), b(6, 1, 2.5, 10, 3.5, 14, M), b(7, 1, 1.5, 9, 3.5, 2.5, M),
             b(7, 3.5, 3, 9, 4.3, 13.5, M), b(7, 4.3, 7, 9, 7, 10, S), b(7.9, 7, 8, 8.1, 9, 8.2, K),
             b(7.4, 3.5, 12.5, 8.6, 4.5, 15, D)]
    elif cls == "colossus":
        p = [b(4, 0, 6, 12, 1, 11, D), b(4.5, 1, 6.5, 7.5, 6, 10, D), b(8.5, 1, 6.5, 11.5, 6, 10, D),
             b(3.5, 6, 5, 12.5, 11, 11, M), b(6.5, 11, 6, 9.5, 14, 10, S), b(7, 12.3, 5.8, 9, 13, 6, G),
             b(1.5, 7, 6, 3.5, 10, 9, S), b(12.5, 7, 6, 14.5, 10, 9, S),
             b(1.9, 7.8, 1.5, 3.1, 8.8, 6, K), b(12.9, 7.8, 1.5, 14.1, 8.8, 6, K),
             b(6, 7, 11, 10, 11, 14, A), b(7.2, 8.2, 14, 8.8, 9.8, 14.4, G)]
    elif cls == "automata":
        p = [b(4, 0, 4, 12, 1, 12, D)]
        for lx, lz in ((4.5, 4.5), (10.5, 4.5), (4.5, 10.5), (10.5, 10.5)):
            p.append(b(lx, 1, lz, lx + 1, 4, lz + 1, S))
        p += [b(4, 4, 4, 12, 9, 12, M), b(6, 9, 5, 10, 11, 9, S), b(7, 9.8, 4.8, 9, 10.4, 5, G),
              b(7.4, 9.5, 1.5, 8.6, 10.5, 5, K)]
    elif cls == "airship":
        p = stand(5)
        p += [b(6, 5, 5, 10, 8, 11, S), b(5, 8, 3.5, 11, 9.5, 12.5, M), b(4, 9.5, 2.5, 12, 13, 13.5, M),
              b(5, 13, 3.5, 11, 14, 12.5, M), b(5.5, 9.5, 2.3, 10.5, 12, 3, M), b(4.2, 10.8, 2.5, 11.8, 11.4, 13.5, D)]
        p += [b(7.6, 8, 13.5, 8.4, 13, 15.5, D), b(5.5, 10.3, 13.5, 10.5, 11, 15, D), b(7, 5.5, 11, 9, 7, 12, K)]
    elif cls == "skyfortress":
        p = stand(5)
        p += [b(3, 5, 4, 13, 8.5, 12, S), b(2, 8.5, 1.5, 14, 12.5, 14.5, M), b(3.5, 12.5, 3, 12.5, 14, 13, M),
              b(2, 10, 1.5, 14, 10.7, 14.5, D), b(0.8, 6.5, 5, 3, 10, 11, D), b(13, 6.5, 5, 15.2, 10, 11, D),
              b(7, 8.5, 0, 9, 9.5, 1.5, K), b(5, 5.5, 2.5, 6, 6.2, 4, K), b(10, 5.5, 2.5, 11, 6.2, 4, K),
              b(7, 14, 7, 9, 15.5, 9, G)]
    elif cls == "stronghold":
        p = [b(1, 0, 1, 15, 2, 15, D), b(2, 2, 3, 14, 6, 13, M), b(7, 2, 2.7, 9, 4.5, 3, K),
             b(6, 6, 6, 10, 9.5, 10, S), b(7.9, 9.5, 7.9, 8.1, 12, 8.1, K), b(8.1, 10.5, 7.9, 9.8, 12, 8.1, G)]
        for tx, tz in ((2, 3), (11, 3), (2, 10), (11, 10)):
            p += [b(tx, 2, tz, tx + 3, 9, tz + 3, S), b(tx - 0.3, 9, tz - 0.3, tx + 3.3, 9.8, tz + 3.3, M)]
    elif cls == "srs":
        p = [b(2, 0, 2, 14, 1, 14, D)]
        for cx, cz, y in ((8, 3, 3), (4, 9, 2), (12, 9, 2)):
            p += [b(cx - 0.4, y - 1, cz - 0.4, cx + 0.4, y, cz + 0.4, S),
                  b(cx - 0.5, y, cz - 2, cx + 0.5, y + 0.8, cz + 2, M),
                  b(cx - 2.3, y + 0.2, cz - 0.6, cx + 2.3, y + 0.5, cz + 0.8, S),
                  b(cx - 1, y + 0.2, cz + 1.4, cx + 1, y + 0.45, cz + 2.2, S),
                  b(cx - 0.15, y + 0.8, cz - 1, cx + 0.15, y + 1.3, cz - 0.4, K)]
    elif cls == "escort":
        p = [b(2, 0, 2, 14, 1, 14, D)]
        for cx, cz in ((5, 5), (11, 10)):
            p += [b(cx - 1.5, 1, cz - 2, cx + 1.5, 2.5, cz + 2, S), b(cx - 1, 2.5, cz - 1, cx + 1, 3.3, cz + 1, M),
                  b(cx - 0.3, 2.6, cz - 2.6, cx + 0.3, 3, cz - 2, K), b(cx - 0.3, 3.3, cz - 0.3, cx + 0.3, 3.8, cz + 0.3, G)]
    else:
        raise ValueError(cls)
    if signature:  # golden unit tag on a tiny base chip in the corner
        p += [b(13, 0, 13, 15, 1, 15, D), b(13.8, 1, 13.8, 14.2, 6, 14.2, K), b(14.2, 4, 13.8, 15.9, 5.8, 14.2, G)]
    return p


def clamp_check(parts):
    for (x1, y1, z1, x2, y2, z2, s) in parts:
        assert x2 > x1 and y2 > y1 and z2 > z1, (x1, y1, z1, x2, y2, z2)
        assert -0.01 <= x1 and x2 <= 16.01 and -0.01 <= z1 and z2 <= 16.01 and y2 <= 16.01, (x1, y1, z1, x2, y2, z2)
