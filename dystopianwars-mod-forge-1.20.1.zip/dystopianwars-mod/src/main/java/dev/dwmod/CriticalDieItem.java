package dev.dwmod;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

public class CriticalDieItem extends Item {
    private static final String[] KEYS = {"breach", "structural", "hazard", "shredded", "navlock", "sysfail"};

    public CriticalDieItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            int face = DiceLogic.rollCritical(bound -> level.random.nextInt(bound));
            MutableComponent msg = Component.translatable("msg." + DystopianWarsMod.MODID + ".crit.header",
                    player.getDisplayName()).withStyle(ChatFormatting.RED);
            msg.append(Component.translatable("crit." + DystopianWarsMod.MODID + "." + KEYS[face]).withStyle(ChatFormatting.WHITE));
            ActionDiceItem.broadcast(level, player, msg);
            player.getCooldowns().addCooldown(this, 10);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip." + DystopianWarsMod.MODID + ".critical_die.1").withStyle(ChatFormatting.GRAY));
    }
}
