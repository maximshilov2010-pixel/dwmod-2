package dev.dwmod;

import java.util.ArrayList;
import java.util.List;

/**
 * Pure text pagination (no Minecraft classes). Text is hard-wrapped into short physical lines so that a page
 * never overflows. A line "=====" forces a page break; a line starting with "# " is a header.
 * Every physical line of a header keeps the "# " prefix in the output.
 */
public final class BookPaginator {
    private BookPaginator() {}

    public static final int WIDTH = 17;
    public static final int HEADER_WIDTH = 13;
    public static final int MAX_LINES = 12;

    /** Wraps one logical line into physical lines no longer than width characters. */
    public static List<String> wrap(String text, int width) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String word : text.split(" ", -1)) {
            String w = word;
            while (w.length() > width) {
                if (cur.length() > 0) {
                    out.add(cur.toString());
                    cur.setLength(0);
                }
                out.add(w.substring(0, width));
                w = w.substring(width);
            }
            if (cur.length() == 0) {
                cur.append(w);
            } else if (cur.length() + 1 + w.length() <= width) {
                cur.append(' ').append(w);
            } else {
                out.add(cur.toString());
                cur.setLength(0);
                cur.append(w);
            }
        }
        out.add(cur.toString());
        return out;
    }

    public static List<String> paginate(String text) {
        List<String> pages = new ArrayList<>();
        List<String> page = new ArrayList<>();
        for (String line : text.replace("\r", "").split("\n", -1)) {
            if (line.trim().equals("=====")) {
                flush(pages, page);
                continue;
            }
            boolean header = line.startsWith("# ");
            List<String> physical = wrap(header ? line.substring(2) : line, header ? HEADER_WIDTH : WIDTH);
            for (String p : physical) {
                if (page.isEmpty() && p.trim().isEmpty()) {
                    continue; // no blank lines at the top of a page
                }
                if (page.size() >= MAX_LINES) {
                    flush(pages, page);
                    if (p.trim().isEmpty()) {
                        continue;
                    }
                }
                page.add(header ? "# " + p : p);
            }
        }
        flush(pages, page);
        return pages;
    }

    private static void flush(List<String> pages, List<String> page) {
        if (!page.isEmpty()) {
            pages.add(String.join("\n", page) + "\n");
            page.clear();
        }
    }
}
