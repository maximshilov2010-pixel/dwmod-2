package dev.dwmod;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(DystopianWarsMod.MODID)
public class DystopianWarsMod {
    public static final String MODID = "dystopianwars";

    public DystopianWarsMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModRegistry.register(bus);
    }
}
