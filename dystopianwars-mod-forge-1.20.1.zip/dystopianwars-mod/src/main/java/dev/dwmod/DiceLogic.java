package dev.dwmod;

import java.util.function.IntUnaryOperator;

/** Pure game logic (no Minecraft classes) so it can be unit-tested. Faces follow Rule Book 4.00. */
public final class DiceLogic {
    private DiceLogic() {}

    public static final int BLANK = 0, STD_COUNTER = 1, HEAVY_COUNTER = 2, STD_STRIKE = 3, HEAVY_STRIKE = 4, EXPLODING = 5;
    public static final int MAX_DICE = 400;

    public static final class Result {
        public final int[] faces = new int[6];
        public int total;
        public int extra;

        /** Standard Strike = 1 Hit, Heavy and Exploding = 2 Hits. */
        public int hits() {
            return faces[STD_STRIKE] + 2 * (faces[HEAVY_STRIKE] + faces[EXPLODING]);
        }

        /** Standard Counter negates 1 Hit, Heavy Counter negates 2. */
        public int counters() {
            return faces[STD_COUNTER] + 2 * faces[HEAVY_COUNTER];
        }
    }

    /** Rolls a pool; every Exploding Strike adds one more die, and new Exploding Strikes keep chaining. */
    public static Result roll(int dice, IntUnaryOperator rng) {
        Result r = new Result();
        int toRoll = Math.max(0, dice);
        boolean first = true;
        while (toRoll > 0 && r.total < MAX_DICE) {
            int exploded = 0;
            for (int i = 0; i < toRoll && r.total < MAX_DICE; i++) {
                int face = rng.applyAsInt(6);
                r.faces[face]++;
                r.total++;
                if (!first) {
                    r.extra++;
                }
                if (face == EXPLODING) {
                    exploded++;
                }
            }
            first = false;
            toRoll = exploded;
        }
        return r;
    }

    public static int rollCritical(IntUnaryOperator rng) {
        return rng.applyAsInt(6);
    }

    /** Range band: 0 close, 1 standard, 2 extreme, 3 exactly 10 (close/standard), 4 exactly 30 (standard/extreme). */
    public static int rangeBand(double inches) {
        double eps = 1.0E-9D;
        if (Math.abs(inches - 10.0D) < eps) return 3;
        if (Math.abs(inches - 30.0D) < eps) return 4;
        if (inches < 10.0D) return 0;
        if (inches < 30.0D) return 1;
        return 2;
    }
}
