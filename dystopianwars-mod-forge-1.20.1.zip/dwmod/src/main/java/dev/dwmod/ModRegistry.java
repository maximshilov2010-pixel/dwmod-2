package dev.dwmod;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModRegistry {
    private ModRegistry() {}

    private static final String ID = DystopianWarsMod.MODID;

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, ID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ID);

    public static final RegistryObject<Item> ACTION_DICE =
            ITEMS.register("action_dice", () -> new ActionDiceItem(new Item.Properties().stacksTo(64)));
    public static final RegistryObject<Item> CRITICAL_DIE =
            ITEMS.register("critical_die", () -> new CriticalDieItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> RULER =
            ITEMS.register("ruler", () -> new RulerItem(new Item.Properties().stacksTo(1)));

    private static final Map<String, List<RegistryObject<Item>>> FACTION_ITEMS = new LinkedHashMap<>();
    private static final Map<String, RegistryObject<Item>> ICONS = new LinkedHashMap<>();
    private static final List<RegistryObject<Item>> MARKER_ITEMS = new ArrayList<>();

    private static BlockBehaviour.Properties tokenProps() {
        return BlockBehaviour.Properties.of().instabreak().noOcclusion().sound(SoundType.WOOD);
    }

    private static RegistryObject<Item> registerToken(String id, String faction, int color, String unitClass, boolean signature) {
        RegistryObject<Block> block = BLOCKS.register(id, () -> new UnitTokenBlock(tokenProps()));
        return ITEMS.register(id, () -> new UnitBlockItem(block.get(), new Item.Properties(), id, faction, color, unitClass, signature));
    }

    static {
        for (UnitData.Faction f : UnitData.FACTIONS) {
            FACTION_ITEMS.put(f.id(), new ArrayList<>());
        }
        for (UnitData.Unit u : UnitData.UNITS) {
            int color = 0xFFFFFF;
            for (UnitData.Faction f : UnitData.FACTIONS) {
                if (f.id().equals(u.faction())) {
                    color = f.color();
                }
            }
            RegistryObject<Item> item = registerToken(u.id(), u.faction(), color, u.unitClass(), u.signature());
            FACTION_ITEMS.get(u.faction()).add(item);
            if (u.id().equals(u.faction() + "_generic_cruiser") || u.id().equals("crown_albion_cruiser")
                    || u.id().equals("imperium_stark_imperium_skyfortress")) {
                ICONS.put(u.faction(), item);
            }
        }
        for (String m : UnitData.MARKERS) {
            MARKER_ITEMS.add(registerToken(m, "neutral", 0x8A8F98, "", false));
        }

        for (UnitData.Faction f : UnitData.FACTIONS) {
            final String fid = f.id();
            TABS.register("faction_" + fid, () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + ID + "." + fid))
                    .icon(() -> new ItemStack(ICONS.get(fid).get()))
                    .displayItems((params, out) -> {
                        for (String book : UnitData.BOOKS.getOrDefault(fid, List.of("faction_" + fid))) {
                            out.accept(GuideBooks.create(book));
                        }
                        for (RegistryObject<Item> it : FACTION_ITEMS.get(fid)) {
                            out.accept(it.get());
                        }
                    })
                    .build());
        }

        TABS.register("rules", () -> CreativeModeTab.builder()
                .title(Component.translatable("itemGroup." + ID + ".rules"))
                .icon(() -> new ItemStack(ACTION_DICE.get()))
                .displayItems((params, out) -> {
                    for (String book : new String[]{"rules_0_start", "rules_1_basics", "rules_2_movement",
                            "rules_3_attacks", "rules_4_victory", "rules_5_advanced", "rules_6_armies"}) {
                        out.accept(GuideBooks.create(book));
                    }
                    out.accept(RULER.get());
                    out.accept(ACTION_DICE.get());
                    out.accept(CRITICAL_DIE.get());
                    for (RegistryObject<Item> it : MARKER_ITEMS) {
                        out.accept(it.get());
                    }
                })
                .build());
    }

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
    }
}
