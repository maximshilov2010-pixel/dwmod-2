"""Generates Russian guide books (.txt) for the full-roster factions (Crown, Imperium)."""
import os, re
import data_crown as C
import data_imperium as I

CAT_RU = {"Flagship": "Флагманы", "Line": "Линия", "Patrol": "Патруль", "Support": "Поддержка", "Scout": "Разведка", "Logistical": "Логистика"}
CATS = list(CAT_RU)
GLOSS = {  # short Russian summaries; see the official Rules Glossary for exact wording
 "Ablative Armour": "стойкая броня: первые попадания по ней частично гасятся",
 "Agile": "ловкость: проще уходить из-под огня и поворачивать",
 "Amphibious": "может идти и по воде, и по суше",
 "Attachment": "юнит прикрепляется к родителю и действует вместе с ним",
 "Auxiliary Mine Layer": "может ставить мины по ходу движения",
 "Boarding Parties": "абордажные партии: атака вплотную (число = сила)",
 "Carrier": "авианосец: несёт SRS-эскадрильи (число = ёмкость)",
 "Civilian Vessel": "гражданское судно, не боевое",
 "Daredevil Crew": "лихой экипаж: рискованные манёвры",
 "Deceptive Deployment": "обманное развёртывание",
 "Defensive": "оборонительный юнит",
 "Elevated": "приподнят над водой/землёй",
 "Flak Barrage": "заградительный зенитный огонь по SRS и авиации (число = мощность)",
 "Flight Command": "управление полётом эскадрилий",
 "Flotsam": "оставляет обломки на месте гибели",
 "Forward Deployment": "выставляется впереди обычной зоны",
 "Ground Assault": "высадка десанта на сушу (число = сила)",
 "Guardian Generator": "даёт кубики в общий Guardian Pool (число = кубики)",
 "Guardian Surge": "усиление Guardian Pool",
 "Heavy Prow": "тяжёлый таран носом (число = сила)",
 "Heavy Shield Generator": "тяжёлый генератор щитов",
 "Hunter": "охотник: бонус против указанного типа цели",
 "Hydrophone Relay": "гидрофонная связь: обнаружение подлодок",
 "Inspirational": "вдохновляет экипажи в указанном радиусе",
 "Lateral Engines": "боковые двигатели: сдвиг в сторону (число = дюймы)",
 "Light Vessel": "лёгкое судно (особые правила попаданий)",
 "Logistical Support": "поддержка снабжения союзников",
 "Maritime Patrol": "морской патруль",
 "Mine Layer": "постановщик мин",
 "Mine Sweeper": "тральщик: чистит мины",
 "Platform": "стационарная платформа",
 "Priority Signals": "приоритетные сигналы связи",
 "Raking Strike": "рубящий проход вдоль борта цели (число = сила)",
 "Repair Facilities": "ремонтные мощности (число = мощность)",
 "Resupply": "пополнение боезапаса союзников (число = мощность)",
 "Shallow Draught": "малая осадка: проходит мелководье",
 "Sky Commandos": "воздушные десантники",
 "Stockpile": "запас снабжения (число = ёмкость)",
 "Stoic": "стойкость к потерям духа",
 "Strategic Asset": "ценный актив, даёт очки при удержании (число = ценность)",
 "Submarauder": "подводный рейдер",
 "Unexpected Arrival": "внезапное появление из глубины",
 "Boosted Propulsion": "форсаж: +дюймы к движению",
 "Underwater Carrier": "подводный авианосец (число = ёмкость)",
 "SRS": "Short Range Squadron: эскадрилья ближнего действия (штурмовики, перехватчики, мелкие подлодки)",
 "Arc (X)": "дуга Империума: перед броском атаки оружие бросает X кубиков Critical Damage",
 "Voltaic": "вольтаика: Firepower растёт за каждый System Failure на цели",
}
QUAL = {
 "Aerial": "может стрелять по воздушным целям", "Barrage": "залп навесом, по площади",
 "Blast (X)": "взрыв радиусом X", "Bomb": "бомбовая атака по цели под собой",
 "Breach (X)": "X критов Breach при попадании", "Devastating (X)": "добавляет X Critical Damage",
 "Hazard (X)": "X критов Hazard", "High Velocity (X)": "высокая скорость: X бонуса", "Homing": "самонаведение",
 "Limited": "ограниченный боезапас", "Navigation Lock (X)": "X критов Navigation Lock", "Piercing (X)": "X критов Structural Failure",
 "Shredded Defences (X)": "X критов Shredded Defences", "Submerged": "подводная атака", "Torpedo": "торпедная атака",
}

def slug(n):
    s = re.sub(r"[^a-z0-9]+", "_", n.lower().replace("ö", "o").replace("ü", "u").replace("ä", "a").replace("ß", "ss"))
    return s.strip("_")

def pts(u): return f"{u['pts']} pts" if u.get("pts") else "pts: нет в источнике"

def crown_entry(u):
    s = u["stats"]
    t = [f"# {u['name']}", f"{CAT_RU[u['cat']]} · {pts(u)}", f"Тип: {u['traits']}",
         f"MAS {s['MAS']}  SPD {s['SPD']}", f"TRN {s['TRN']}  DEF {s['DEF']}", f"ARM {s['ARM']}  HUL {s['HUL']}",
         f"ACT {s['ACT']}  BRD {s['BRD']}", f"REP {s['REP']}  CRW {s['CRW']}"]
    if u.get("models"): t.append(f"Моделей: {u['models']}")
    t.append(f"Свойства: {u['props']}")
    t.append(f"Системы: {u['systems']}")
    t.append(f"Оружие: {u['weapons']}")
    if u.get("opts"): t.append(f"Опции: {u['opts']}")
    if u.get("escorts"): t.append(f"Эскорт: {u['escorts']}")
    return "\n".join(t)

def imperium_entry(u):
    s = u["stats"]
    t = [f"# {u['name']}", f"{CAT_RU[u['cat']]} · {u['pts']} pts · моделей {u['models']}",
         f"MAS {s['MAS']}  SPD {s['SPD']}", f"TRN {s['TRN']}  DEF {s['DEF']}", f"ARM {s['ARM']}  HUL {s['HUL']}",
         f"ACT {s['ACT']}  BRD {s['BRD']}", f"REP {s['REP']}  CRW {s['CRW']}",
         f"Свойства: {u['props']}", f"Системы: {u['systems']}"]
    for wn, arc, cse, q in u["weapons"]:
        t.append(f"> {wn} [{arc}] {cse}: {q}")
    if not u["weapons"]:
        t.append("Оружия нет")
    if u["opts"]:
        t.append(f"Опции: {u['opts']}")
    return "\n".join(t)

def write(path, text):
    with open(path, "w", encoding="utf-8", newline="\n") as f: f.write(text)

def write_books(d):
    os.makedirs(d, exist_ok=True)
    out = {"crown": [], "imperium": []}
    # ---------------- CROWN ----------------
    crown_bg = open(os.path.join(d, "faction_crown.txt"), encoding="utf-8").read().split("=====\n# Юниты во вкладке")[0].split("=====\n# Во вкладке")[0]
    crown_bg += ("=====\n# Во вкладке\nВсе 52 юнита из ORBAT Crown 4.02 с подписями. Наведите на предмет — увидите категорию, очки и главные характеристики.\n"
                 "Книги: юниты по категориям, оружие, термины, боевые флоты.\n")
    write(os.path.join(d, "faction_crown.txt"), crown_bg)
    out["crown"].append("faction_crown")
    for cat in CATS:
        us = [u for u in C.UNITS if u["cat"] == cat]
        text = f"@title Корона: {CAT_RU[cat]}\n# {CAT_RU[cat]} Короны\nЮнитов: {len(us)}. Порядок статов: MAS SPD TRN DEF ARM HUL ACT BRD REP CRW. Источник: ORBAT Crown 4.02.\n=====\n" + "\n=====\n".join(crown_entry(u) for u in us) + "\n"
        write(os.path.join(d, f"crown_units_{cat.lower()}.txt"), text); out["crown"].append(f"crown_units_{cat.lower()}")
    w = ["@title Корона: Оружие", "# Оружие Короны", "Дальности: Close / Standard / Extreme. «-» значит, что оружие на этой дальности не стреляет. Цифры = кубики атаки. Дуги: F вперёд, P левый борт, S правый, A корма.", "====="]
    for n, arcs, cse, q in C.WEAPONS:
        w.append(f"# {n}\nДуги: {arcs}\nC/S/E: {cse}\nКачества: {q}\n=====")
    write(os.path.join(d, "crown_weapons.txt"), "\n".join(w[:-1]) + "\n"); out["crown"].append("crown_weapons")
    g = ["@title Корона: Термины", "# Термины Короны", "Краткий перевод свойств и систем. Точные формулировки — Rules Glossary 4.0.", "====="]
    used = [k for k in GLOSS if any(k in (u["props"] + ";" + u["systems"]) for u in C.UNITS)]
    for k in used: g.append(f"{k}: {GLOSS[k]}")
    g.append("=====\n# Качества оружия")
    for k, v in QUAL.items(): g.append(f"{k}: {v}")
    g.append("=====\n# Guardian Generator\n" + C.SPECIAL[0][1] + "\n=====\n" + C.SPECIAL[1][1])
    write(os.path.join(d, "crown_glossary.txt"), "\n".join(g) + "\n"); out["crown"].append("crown_glossary")
    f = ["@title Корона: Флоты", "# Боевые флоты Короны", "Основной и специализированные флоты по ORBAT 4.02.", "====="]
    for n, kind, comp, bonus in C.BATTLEFLEETS:
        f.append(f"# {n}\nТип: {kind}\nСостав: {comp}\nБонус: {bonus}\n=====")
    f.append("# Наёмники\nBlack Wolf Hunting Pack; Scions of Jutland; Crimson League Privateers; Honorable Eclipse Company.")
    write(os.path.join(d, "crown_fleets.txt"), "\n".join(f) + "\n"); out["crown"].append("crown_fleets")
    # ---------------- IMPERIUM ----------------
    bg = """@title Империум (Imperium)
# Империум
Автократия с центром в Берлине, от Балтики до Адриатики. Кайзер Фридрих Грундер — «Дед Европы», рейхсканцлер — Отто фон Бисмарк.
=====
# Власть
Реальная сила за троном — Тевтонские рыцари: шесть Ритов, великий магистр Анна фон Мальберг.
Земли: Пруссия, Австрия, Бавария и Новая Скандинавская конфедерация.
=====
# Технологии
Железнодорожная сеть и Arc/вольтаическое оружие. Его создал рыцарь-светоч Генрих Румкорф на основе работ Теслы.
=====
# Доктрина
Скорость и одновременные наступления на нескольких направлениях.
Соперники: Содружество, Франция, Корона, итальянские государства.
Скандинавские Scions of Jutland — рейдеры из засад.
=====
# Во вкладке
54 юнита Империума с подписями и полными профилями.
Профили взяты из ORBAT Imperium 4.00b (очки и цифры могут отличаться в более новых версиях). Нет лишь описаний терминов Империума.
"""
    write(os.path.join(d, "faction_imperium.txt"), bg); out["imperium"].append("faction_imperium")
    for cat in CATS:
        us = [u for u in I.UNITS if u["cat"] == cat]
        t = f"@title Империум: {CAT_RU[cat]}\n# {CAT_RU[cat]} Империума\nЮнитов: {len(us)}. Порядок статов: MAS SPD TRN DEF ARM HUL ACT BRD REP CRW. Источник: ORBAT Imperium 4.00b. Оружие: C/S/E = дальность Close/Standard/Extreme.\n=====\n"
        t += "\n=====\n".join(imperium_entry(u) for u in us) + "\n"
        write(os.path.join(d, f"imperium_units_{cat.lower()}.txt"), t); out["imperium"].append(f"imperium_units_{cat.lower()}")
    r = ["@title Империум: Оружие", "# Оружие Империума", "Основные орудия Империума. Цифры дальности и качества смотрите в записи юнита. Hardpoint-оружие меняется опциями.", "====="]
    r += [f"- {w}" for w in I.WEAPONS]
    r += ["=====", "# Arc (X)\n" + GLOSS["Arc (X)"], "=====\n# Voltaic\n" + GLOSS["Voltaic"],
          "=====\n# Жетоны SRS\nBlitzen Bombers, Messer Interceptors, Vali Midget Subs, Landing Party, Escort."]
    write(os.path.join(d, "imperium_weapons.txt"), "\n".join(r) + "\n"); out["imperium"].append("imperium_weapons")
    return out
